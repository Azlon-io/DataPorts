
- download the java client and config.properties
- install the latest JRE for your operating system
- extract the zip into a folder (please do not extract this on your desktop because of right issues).
- create a subdirectory for the downloads
- update the config.properties file. The next values need to be updated
	- deviceId
	- sharedAccessKey
	- autoSaveLocation
	- dataportname
- start this client by the commandline using the next command:
java -XstartOnFirstThread -jar TestClientMac.jar
- After this a client should appear and you should be able to send files to other DataPorts!

